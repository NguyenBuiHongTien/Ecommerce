-- Tạo cơ sở dữ liệu
CREATE DATABASE MidTerm;

-- Sử dụng cơ sở dữ liệu vừa tạo
USE MidTerm;

-- Tạo bảng Users
CREATE TABLE Users (
    UserID INT IDENTITY(1,1) PRIMARY KEY,         -- Khóa chính, tự động tăng (IDENTITY thay vì AUTO_INCREMENT)
    Username VARCHAR(255) NOT NULL UNIQUE,         -- Tên đăng nhập, không được trùng lặp và không null
    Password VARCHAR(255) NOT NULL,                -- Mật khẩu đã mã hóa, không null
    FullName VARCHAR(255) NOT NULL,                -- Họ tên đầy đủ của khách hàng, không null
    Email VARCHAR(255) NOT NULL UNIQUE,            -- Email, không được trùng lặp và không null
    Phone VARCHAR(15),                             -- Số điện thoại, có thể để trống
    Address TEXT,                                  -- Địa chỉ của khách hàng
    Role VARCHAR(50) DEFAULT 'customer'            -- Phân quyền người dùng, mặc định là 'customer'
);



-- Tạo bảng products
CREATE TABLE Products (
    ProductID INT IDENTITY(1,1) PRIMARY KEY, -- Tạo trường ProductID tự động tăng
    ProductName VARCHAR(255) NOT NULL, -- Tên sản phẩm, không thể null
    Description TEXT, -- Mô tả chi tiết về sản phẩm
    Price DECIMAL(10,2), -- Giá sản phẩm, với 10 chữ số tổng cộng và 2 chữ số thập phân
    StockQuantity INT, -- Số lượng tồn kho
    CategoryID INT, -- Liên kết tới bảng Categories
    ImageURL VARCHAR(255), -- Đường dẫn hình ảnh sản phẩm
    FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID) -- Liên kết khóa ngoại tới bảng Categories
);


-- Tạo bảng Categories
CREATE TABLE Categories (
    CategoryID INT IDENTITY(1,1) PRIMARY KEY, -- Tạo trường CategoryID tự động tăng
    CategoryName VARCHAR(255) NOT NULL, -- Tên danh mục, không thể null
    Description TEXT -- Mô tả về danh mục sản phẩm
);


-- Thêm các danh mục vào bảng Categories (nếu chưa có)
INSERT INTO Categories (CategoryName, Description)
VALUES 
('Điện thoại', 'Các loại điện thoại di động'),
('Laptop', 'Máy tính xách tay và phụ kiện'),
('Quần áo', 'Trang phục thời trang cho mọi lứa tuổi'),
('Giày dép', 'Các loại giày dép thời trang'),
('Đồ gia dụng', 'Các sản phẩm gia dụng phục vụ nhu cầu trong gia đình');

-- Thêm 5 sản phẩm vào bảng Products
INSERT INTO Products (ProductName, Description, Price, StockQuantity, CategoryID, ImageURL)
VALUES
('iPhone 14', 'Điện thoại thông minh của Apple', 22999.99, 50, 1, 'https://example.com/images/iphone14.jpg'),
('Dell XPS 13', 'Laptop cao cấp của Dell', 18999.99, 30, 2, 'https://example.com/images/dell_xps_13.jpg'),
('Áo thun nam', 'Áo thun thời trang nam', 199.99, 100, 3, 'https://example.com/images/ao_thun_nam.jpg'),
('Nike Air Max 2021', 'Giày thể thao Nike Air Max', 499.99, 70, 4, 'https://example.com/images/nike_air_max_2021.jpg'),
('Máy xay sinh tố Philips', 'Máy xay sinh tố Philips HR2118', 1299.99, 40, 5, 'https://example.com/images/may_xay_sinh_to_philips.jpg');



