import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './css/register.css'; // Import file CSS

function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [address, setAddress] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    axios.get(`${process.env.REACT_APP_API_URL}/session/check-session`)
      .then((response) => {
        // Nếu người dùng đã đăng nhập, điều hướng họ đến trang home
        if (response.data.loggedIn) {
          localStorage.setItem('user', JSON.stringify(response.data.user));
          navigate('/home');
        }
      })
      .catch((error) => {
        // Nếu không có session (người dùng chưa đăng nhập), cho phép họ vào trang đăng nhập
        console.log('User is not logged in');
        navigate('/login');
      });
  }, [navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Gửi đầy đủ thông tin người dùng (bao gồm fullName, phone, address)
      const response = await axios.post(`${process.env.REACT_APP_API_URL}/accounts/register`, { 
        username, 
        email, 
        password, 
        fullName, 
        phone, 
        address 
      });
      alert(response.data);
      navigate('/login'); // Điều hướng đến trang đăng nhập sau khi đăng ký thành công
    } catch (err) {
      alert('Error: ' + (err.response ? err.response.data : 'Unknown error'));
    }
  };

  return (
    <div className="container">
      <h1>Register</h1>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" 
          placeholder="Username" 
          value={username} 
          onChange={(e) => setUsername(e.target.value)} 
          required
        />
        <input 
          type="email" 
          placeholder="Email" 
          value={email} 
          onChange={(e) => setEmail(e.target.value)} 
          required
        />
        <input 
          type="password" 
          placeholder="Password" 
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          required
        />
        <input 
          type="text" 
          placeholder="Full Name" 
          value={fullName} 
          onChange={(e) => setFullName(e.target.value)} 
          required
        />
        <input 
          type="text" 
          placeholder="Phone" 
          value={phone} 
          onChange={(e) => setPhone(e.target.value)} 
          required
        />
        <textarea 
          placeholder="Address" 
          value={address} 
          onChange={(e) => setAddress(e.target.value)} 
          required
        />
        <button type="submit">Register</button>
      </form>
      <a href="/login" className="link">Already have an account? Login here</a> {/* Link đến trang đăng nhập */}
    </div>
  );
}

export default Register;
