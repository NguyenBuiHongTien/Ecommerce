import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './css/productsList.css';

function ProductList() {
  const [products, setProducts] = useState([]);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [username, setUsername] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Get user information from sessionStorage
        const storedUsername = sessionStorage.getItem('user');
        const parsedUser = storedUsername ? JSON.parse(storedUsername) : null;

        if (parsedUser?.username) {
          setUsername(parsedUser.username);
        }

        // Check user session
        const sessionResponse = await axios.get(`${process.env.REACT_APP_API_URL}/session/check-session`, {
          withCredentials: true,
        });

        if (sessionResponse.data.loggedIn && sessionResponse.data.user?.role === 'admin') {
          setIsAdmin(true);
        }

        // Get product list from API
        const productResponse = await axios.get(`${process.env.REACT_APP_API_URL}/products/products`);
        if (Array.isArray(productResponse.data)) {
          setProducts(productResponse.data);
        } else {
          throw new Error('Invalid product data format');
        }
      } catch (err) {
        setError('An error occurred while loading the product list.');
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleDelete = async (id) => {
    try {
      await axios.delete(`${process.env.REACT_APP_API_URL}/products/products/${id}`);
      setProducts((prevProducts) => prevProducts.filter((product) => product.ProductID !== id));
    } catch (error) {
      console.error('Error deleting product:', error);
      setError('An error occurred while deleting the product.');
    }
  };

  if (loading) {
    return <div>Loading data...</div>;
  }

  if (error) {
    return <div className="error-message">{error}</div>;
  }

  return (
    <div className="product-list-container">
      {/* Navbar */}
      <nav className="navbar">
        <ul className="navbar-list">
          <li><Link to="/">Home</Link></li>
          <li><Link to="/products">Products</Link></li>
          <li><a href="#">Discounts</a></li>
          <li><a href="#">About Us</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Blog</a></li>
          <li><a href="#">Pages</a></li>
          <li className="search">
            <input type="text" placeholder="Search..." />
            <button>Search</button>
          </li>
          <li className="user-name">
            {username ? (
              <span>Hello, {username}</span>
            ) : (
              <>
                <Link to="/login">Login</Link> | <Link to="/register">Register</Link>
              </>
            )}
          </li>
        </ul>
      </nav>

      <h1>Product List</h1>
      {isAdmin && (
        <Link to="/add-product" className="btn add-product-btn">Add New Product</Link>
      )}

      <table className="product-table">
        <thead>
          <tr>
            <th>Image</th>
            <th>Product Name</th>
            <th>Price</th>
            <th>Description</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {products.length > 0 ? (
            products.map((product) => (
              <tr key={product.ProductID}>
                <td>
                  <img
                    src={product.ImageURL || 'placeholder.jpg'}
                    alt={product.ProductName}
                    className="product-image"
                  />
                </td>
                <td>{product.ProductName}</td>
                <td>{product.Price || 'N/A'}</td>
                <td>{product.Description}</td>
                <td>
                  <Link to={`/products/${product.ProductID}`} className="btn view-btn">View</Link>
                  {isAdmin && (
                    <>
                      <Link to={`/edit-product/${product.ProductID}`} className="btn edit-btn">Edit</Link>
                      <button
                        onClick={() => handleDelete(product.ProductID)}
                        className="btn delete-btn"
                      >
                        Delete
                      </button>
                    </>
                  )}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5">No products available.</td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export default ProductList;
