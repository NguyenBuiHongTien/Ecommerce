import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';
import './css/home.css';

function Home() {
  const [products, setProducts] = useState([]); // State to store product list
  const [username, setUsername] = useState(null); // State to store the username

  // Function to update username from sessionStorage
  const updateUsername = () => {
    const user = sessionStorage.getItem('user');
    if (user) {
      try {
        const parsedUser = JSON.parse(user);
        setUsername(parsedUser.username || null);
      } catch (error) {
        console.error("Error parsing user data:", error); // Log error if data is invalid
      }
    }
  };

  // Get username when component mounts
  useEffect(() => {
    updateUsername();
  }, []);

  // Fetch products from API
  useEffect(() => {
    const fetchProducts = async () => {
      try {
        const response = await axios.get(`${process.env.REACT_APP_API_URL}/products/products`);
        setProducts(response.data); // Update product list
      } catch (error) {
        console.error("Error fetching products:", error);
      }
    };

    fetchProducts();
  }, []);

  return (
    <div className="home-container">
      {/* Navbar */}
      <nav className="navbar">
        <ul className="navbar-list">
          <li><Link to="/home">Home</Link></li>
          <li><Link to="/products">Products</Link></li>
          <li><a href="#">Sale</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Services</a></li>
          <li><a href="#">Blogs</a></li>
          <li><a href="#">Pages</a></li>
          <li className="search">
            <input type="text" placeholder="Search..." />
            <button>Search</button>
          </li>
          <li className="user-name">
            {username ? `Hello, ${username}` : <><a href="/login">Login</a> | <a href="/register">Register</a></>}
          </li>
        </ul>
      </nav>

      {/* Main Content */}
      <h1>Welcome to Our Online Fashion Store</h1>
      <p>
        We offer a wide range of fashion products to help you express your unique style.
        From clothing to shoes and accessories, everything you need is here.
      </p>
      <p>
        Explore our latest collections and special deals only available at our store!
      </p>

      {/* Product Categories */}
      <section className="categories">
        <h2>Product Categories</h2>
        <div className="category-list">
          {products.map(product => (
            <div className="category-item" key={product.ProductID}>
              <img src={product.ImageURL} alt={product.ProductName} />
              <p><strong>{product.ProductName}</strong></p>
              <p>{product.Description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Featured Products */}
      <section className="featured-products">
        <h2>Featured Products</h2>
        <div className="product-list">
          {products.slice(0, 3).map(product => (
            <div className="product-item" key={product.ProductID}>
              <img src={product.ImageURL} alt={product.ProductName} />
              <p><strong>{product.ProductName}</strong></p>
              <p>Price: {product.Price} VND</p>
            </div>
          ))}
        </div>
      </section>

      {/* Special Offers */}
      <section className="offers">
        <h2>Special Offers</h2>
        <p>Get a 20% discount on your first order. Hurry, limited time only!</p>
      </section>
    </div>
  );
}

export default Home;
