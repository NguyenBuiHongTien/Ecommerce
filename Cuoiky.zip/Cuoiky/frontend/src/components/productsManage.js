import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, Link } from 'react-router-dom';
import './css/productManagement.css';

function ProductManagement() {
  const { ProductID } = useParams(); // Lấy product ID từ URL
  const [product, setProduct] = useState(null); // State để lưu thông tin sản phẩm
  const [username, setUsername] = useState(''); // State để lưu tên người dùng

  useEffect(() => {
    console.log('ProductID:', ProductID); // Log giá trị của ProductID để debug
    if (!ProductID) {
      console.error('Product ID is missing');
      return;
    }

    axios
      .get(`${process.env.REACT_APP_API_URL}/products/products/${ProductID}`)
      .then((response) => {
        console.log('API Response:', response.data);
        setProduct(response.data);
      })
      .catch((error) => {
        console.error('Error fetching product:', error.response ? error.response.data : error.message);
      });
  }, [ProductID]);

  // Kiểm tra tên người dùng từ sessionStorage
  useEffect(() => {
    const storedUser = sessionStorage.getItem('user');
    if (storedUser) {
      try {
        const parsedUser = JSON.parse(storedUser);
        setUsername(parsedUser.username || '');
      } catch (error) {
        console.error('Error parsing user data:', error);
      }
    }
  }, []);

  // Hiển thị loading nếu chưa có sản phẩm
  if (!product) return <p>Loading...</p>;

  return (
    <div>
      {/* Navbar */}
      <nav className="navbar">
        <ul className="navbar-list">
          <li><Link to="/home">Home</Link></li>
          <li><Link to="/products">Products</Link></li>
          <li><a href="#">Sale</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Service</a></li>
          <li><a href="#">Blogs</a></li>
          <li><a href="#">Pages</a></li>
          <li className="user-name">
            {username ? `Hello, ${username}` : <><a href="/login">Login</a> | <a href="/register">Register</a></>}
          </li>
        </ul>
      </nav>

      {/* Chi tiết sản phẩm */}
      <div className="product-details">
        <h1>Product Details</h1>
        <p><strong>Product ID:</strong> {product.ProductID}</p>
        <p><strong>Product Name:</strong> {product.ProductName}</p>
        <p><strong>Price:</strong> {product.Price.toLocaleString('en-US', { style: 'currency', currency: 'USD' })}</p>
        <p><strong>Description:</strong> {product.Description}</p>
        <p><strong>Category:</strong> {product.CategoryID}</p>
        <p><strong>Stock Quantity:</strong> {product.StockQuantity}</p>
        <p>
          <strong>Image:</strong>
          <br />
          <img src={product.image} alt={product.ProductName} width="300" />
        </p>
      </div>
    </div>
  );
}

export default ProductManagement;
