// Login.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './css/login.css'; // Import file CSS

function Login() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();


  useEffect(() => {
    axios.get(`${process.env.REACT_APP_API_URL}/session/check-session`)
      .then((response) => {
        // Nếu người dùng đã đăng nhập, điều hướng họ đến trang home
        if (response.data.loggedIn) {
          sessionStorage.setItem('user', JSON.stringify(response.data.user));
          navigate('/home');
        }
      })
      .catch((error) => {
        // Nếu không có session (người dùng chưa đăng nhập), cho phép họ vào trang đăng nhập
        console.log('User is not logged in');
        navigate('/login')
      });
  }, [navigate]);


  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post(`${process.env.REACT_APP_API_URL}/accounts/login`, { username, password });
      console.log("Response data: ", response.data);  // Log phản hồi để kiểm tra
      alert(response.data);
      sessionStorage.setItem('user', JSON.stringify(response.data.user));
      navigate('/home'); // Điều hướng đến trang chính nếu đăng nhập thành công
    } catch (err) {
      console.error("Error: ", err);
      alert('Error: ' + (err.response ? err.response.data : 'Unknown error'));
    }
  };

  return (
    <div className="container">
      <h1>Login</h1>
      <form onSubmit={handleSubmit}>
        <input 
          type="text" 
          placeholder="Username" 
          value={username} 
          onChange={(e) => setUsername(e.target.value)} 
          required
        />
        <input 
          type="password" 
          placeholder="Password" 
          value={password} 
          onChange={(e) => setPassword(e.target.value)} 
          required
        />
        <button type="submit">Login</button>
      </form>
      <a href="/register" className="link">Don't have an account? Register here</a> {/* Link đến trang đăng ký */}
    </div>
  );
}

export default Login;
