import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useParams } from 'react-router-dom';
import './css/updateProductForm.css';

function EditProductForm() {
  const [product, setProduct] = useState({
    name: '',
    price: '',
    description: '',
    image: ''
  });
  const [updatedProduct, setUpdatedProduct] = useState({
    name: '',
    price: '',
    description: '',
    image: ''
  });
  const [username, setUsername] = useState(''); // State để lưu tên người dùng

  const { id } = useParams(); // Lấy ID từ URL
  const navigate = useNavigate();

  // Nếu có id (chỉnh sửa sản phẩm), gọi API để lấy thông tin sản phẩm
  useEffect(() => {
    if (id) {
      axios.get(`${process.env.REACT_APP_API_URL}/products/products/${id}`)
        .then((response) => {
          setProduct(response.data); // Cập nhật state với thông tin sản phẩm
          setUpdatedProduct(response.data); // Cập nhật state cho ô nhập liệu
        })
        .catch((error) => {
          console.error('Error fetching product details:', error);
        });
    }

    // Lấy tên người dùng từ session hoặc localStorage (ví dụ)
    const storedUsername = sessionStorage.getItem('user');
    const parsedUser = JSON.parse(storedUsername);
    console.log('Stored Username:', parsedUser.username); // Debug
    if (parsedUser.username) {
      setUsername(parsedUser.username);
    }
  }, [id]);

  // Xử lý thay đổi trong form input
  const handleChange = (e) => {
    const { name, value } = e.target;
    setUpdatedProduct((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Xử lý submit form
  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .put(`${process.env.REACT_APP_API_URL}/products/products/${id}`, updatedProduct) // Chỉnh sửa sản phẩm
      .then((response) => {
        console.log('Product updated:', response.data);
        navigate('/products'); // Điều hướng về danh sách sản phẩm
      })
      .catch((error) => {
        console.error('Error updating product:', error);
      });
  };

  return (
    <div>
      {/* Navbar */}
      <nav className="navbar">
        <ul className="navbar-list">
          <li><a href="/home">Home</a></li>
          <li><a href="/products">Product</a></li>
          <li><a href="#">Sale</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Service</a></li>
          <li><a href="#">Blogs</a></li>
          <li><a href="#">Pages</a></li>
        </ul>
      </nav>

      {/* Hiển thị tên người dùng */}
      <div className="user-info">
        <h3>Hello, {username ? username : 'Guest'}!</h3>
      </div>

      {/* Product Edit Form */}
      <div className="product-form">
        <h1>Edit Product</h1>
        <h2>Current Product Details</h2>
        <p><strong>Name:</strong> {product.name}</p>
        <p><strong>Price:</strong> {product.price}</p>
        <p><strong>Description:</strong> {product.description}</p>
        <p><strong>Image:</strong> {product.image}</p>

        <h3>Update Product</h3>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>New Name:</label>
            <input
              type="text"
              name="name"
              value={updatedProduct.name}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>New Price:</label>
            <input
              type="number"
              name="price"
              value={updatedProduct.price}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>New Description:</label>
            <input
              type="text"
              name="description"
              value={updatedProduct.description}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>New Image URL:</label>
            <input
              type="text"
              name="image"
              value={updatedProduct.image}
              onChange={handleChange}
            />
          </div>
          <button type="submit">Update Product</button>
        </form>
      </div>
    </div>
  );
}

export default EditProductForm;
