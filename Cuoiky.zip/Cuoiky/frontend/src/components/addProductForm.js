import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import './css/addProductForm.css';

function AddProductForm() {
  const [product, setProduct] = useState({
    name: '',
    price: '',
    description: '',
    image: ''
  });
  const [username, setUsername] = useState('');  // Lưu trữ tên người dùng
  const navigate = useNavigate();

  // Lấy tên người dùng từ localStorage (hoặc từ sessionStorage hoặc từ API)
  useEffect(() => {
    const storedUsername = sessionStorage.getItem('user');
    const parsedUser = JSON.parse(storedUsername);
    console.log('Stored Username:', parsedUser.username); // Debug
    if (parsedUser.username) {
      setUsername(parsedUser.username);
    }
  }, []);

  // Xử lý thay đổi trong form input
  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // Xử lý submit form
  const handleSubmit = (e) => {
    e.preventDefault();

    axios
      .post(`${process.env.REACT_APP_API_URL}/products/products`, product) // Thêm mới sản phẩm
      .then((response) => {
        console.log('Product added:', response.data);
        navigate('/products'); // Điều hướng về danh sách sản phẩm
      })
      .catch((error) => {
        console.error('Error adding product:', error);
      });
  };

  return (
    <div>
      {/* Navbar */}
      <nav className="navbar">
        <ul className="navbar-list">
          <li><a href="/home">Home</a></li>
          <li><a href="/products">Product</a></li>
          <li><a href="#">Sale</a></li>
          <li><a href="#">About</a></li>
          <li><a href="#">Service</a></li>
          <li><a href="#">Blogs</a></li>
          <li><a href="#">Pages</a></li>
        </ul>
      </nav>

      {/* User Info (Tên người dùng) */}
      <div className="user-info">
        <h3>Welcome, {username}!</h3>  {/* Hiển thị tên người dùng */}
      </div>

      {/* Product Form */}
      <div className="product-form">
        <h1>Add Product</h1>
        <form onSubmit={handleSubmit}>
          <div className="form-group">
            <label>Name:</label>
            <input
              type="text"
              name="name"
              value={product.name}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Price:</label>
            <input
              type="number"
              name="price"
              value={product.price}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Description:</label>
            <input
              type="text"
              name="description"
              value={product.description}
              onChange={handleChange}
            />
          </div>
          <div className="form-group">
            <label>Image URL:</label>
            <input
              type="text"
              name="image"
              value={product.image}
              onChange={handleChange}
            />
          </div>
          <button type="submit">Add Product</button>
        </form>
      </div>
    </div>
  );
}

export default AddProductForm;
