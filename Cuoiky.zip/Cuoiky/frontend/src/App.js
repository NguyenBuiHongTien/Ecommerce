import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { BrowserRouter as Router, Routes, Route, useNavigate } from 'react-router-dom';
import Login from './components/login';
import Register from './components/register';
import Home from './components/home';
import ProductList from './components/productsList';
import AddProductForm from './components/addProductForm';
import UpdateProductForm from './components/updateProductForm';
import ProductManagement from './components/productsManage';

function App() {
  const navigate = useNavigate();
  const [isLoggedIn, setIsLoggedIn] = useState(null); // Trạng thái đăng nhập
  const [user, setUser] = useState(null); // Thông tin người dùng

  useEffect(() => {
    console.log('Checking user session...');
    axios.get(`${process.env.REACT_APP_API_URL}/session/check-session`, { withCredentials: true })
      .then((response) => {
        console.log('Session check response:', response.data);
        if (response.data.loggedIn) {
          // Đã đăng nhập -> Cập nhật thông tin trong state và sessionStorage
          setUser(response.data.user);
          sessionStorage.setItem('user', JSON.stringify(response.data.user));
          setIsLoggedIn(true);
          navigate('/home'); // Điều hướng đến trang home
        } else {
          // Chưa đăng nhập -> Xóa thông tin cũ, vẫn cho vào home
          setUser(null);
          sessionStorage.removeItem('user');
          setIsLoggedIn(false);
          navigate('/home'); // Điều hướng đến trang đăng nhập
        }
      })
      .catch((error) => {
        console.error('Error checking session:', error);
        // Xử lý lỗi (có thể điều hướng hoặc hiển thị thông báo)
        setUser(null);
        sessionStorage.removeItem('user');
        setIsLoggedIn(false);
        navigate('/home');
      });
  }, [navigate]);

  return null;
}

function Main() {
  return (
    <Router>
      <Routes>
        <Route path="/home" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/products/:ProductId" element={<ProductManagement />} />
        <Route path="/products" element={<ProductList />} />
        <Route path="/edit-product/:id" element={<UpdateProductForm />} />
        <Route path="/add-product" element={<AddProductForm />} />
        <Route path="/*" element={<App />} /> {/* Kiểm tra phiên người dùng cho mọi đường dẫn */}
      </Routes>
    </Router>
  );
}

export default Main;
