const sql = require('mssql');
const config = require('./config'); 

const connectDB = async () => {
    try {
        const pool = await sql.connect(config);
        console.log('Kết nối cơ sở dữ liệu thành công!');
        return pool;
    } catch (error) {
        console.error('Lỗi kết nối cơ sở dữ liệu:', error);
    }
};

module.exports = connectDB;
