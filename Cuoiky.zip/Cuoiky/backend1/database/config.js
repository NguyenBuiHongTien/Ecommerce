require('dotenv').config();

module.exports = {
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    server: process.env.DB_SERVER,
    database: process.env.DB_NAME,
    options: {
        encrypt: true, // for Azure SQL Database
        trustServerCertificate: true // change to true for local dev / self-signed certs
    }
};
