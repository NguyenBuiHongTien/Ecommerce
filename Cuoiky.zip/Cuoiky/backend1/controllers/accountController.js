const bcrypt = require('bcryptjs');
const sql = require('mssql');


// API cho đăng ký người dùng ('/api/register')
exports.createAccount = async (req, res) => {
    const { username, email, password, fullName, phone, address } = req.body;

    // Kiểm tra xem có thiếu trường nào không
    if (!username || !email || !password || !fullName || !phone || !address) {
        console.log('Missing required fields:', req.body); // Log thông tin nếu thiếu trường
        return res.status(400).send('Missing required fields');
    }

    try {
        // Mã hóa mật khẩu
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Tạo yêu cầu để thực thi câu lệnh SQL
        const request = new sql.Request();
        
        // Thực thi truy vấn SQL để lưu thông tin người dùng vào bảng Users
        const query = `INSERT INTO dbo.Users (username, email, password, fullName, phone, address, role)
                       VALUES ('${username}', '${email}', '${hashedPassword}', '${fullName}', '${phone}', '${address}', 'customer')`;

        await request.query(query);
        console.log('User registered:', { username, email, fullName, phone, address }); // Log thông tin người dùng đã đăng ký

        // Trả về phản hồi thành công
        res.status(201).send('User registered successfully in port 3001');
    } catch (err) {
        console.error('Database error during registration:', err); // Log lỗi khi đăng ký
        res.status(500).send('Error registering user');
    }
};


// API cho đăng nhập người dùng ('/api/login')
// exports.login = async (req, res) => {
//     const { username, password } = req.body;

//     console.log('Login attempt:', { username }); // Log thông tin người dùng đăng nhập

//     try {
//         const request = new sql.Request();
//         const result = await request.query(`SELECT * FROM dbo.Users WHERE username = '${username}'`);

//         if (result.recordset.length > 0) {
//             const user = result.recordset[0]; // Lấy người dùng từ kết quả
            
//             // Kiểm tra xem mật khẩu có hợp lệ không
//             if (!user.password) {
//                 console.error('Password not found for user:', username); // Log thông tin nếu không có mật khẩu
//                 return res.status(500).send('Password not found for user');
//             }

//             const match = await bcrypt.compare(password, user.password); // So sánh mật khẩu

//             if (match) {
//                 req.session.user = { 
//                     username: user.username,
//                     role: user.role }; // Lưu thông tin người dùng vào session

//                 console.log('Login successful, session:', req.session.user); // Log thông tin phiên người dùng
//                 res.status(200).send('Login successful in port 3002');
//             } else {
//                 console.log('Invalid credentials for user:', username); // Log thông tin khi đăng nhập không thành công
//                 res.status(401).send('Invalid credentials');
//             }
//         } else {
//             console.log('Invalid credentials for user:', username); // Log thông tin khi đăng nhập không thành công
//             res.status(401).send('Invalid credentials');
//         }
//     } catch (err) {
//         console.error('Error during login:', err); // Log lỗi khi đăng nhập
//         res.status(500).send('Error during login');
//     }
// };
exports.login = async (req, res) => {
    let { username, password } = req.body;

    // Xử lý đầu vào, loại bỏ khoảng trắng
    username = username.trim();
    password = password.trim();

    // Kiểm tra nếu username hoặc password bị bỏ trống
    if (!username || !password) {
        return res.status(400).json({ errors: [{ msg: 'Username and password are required.' }] });
    }

    console.log('Login attempt:', { username }); // Log thông tin người dùng đăng nhập

    try {
        const request = new sql.Request();
        request.input('username', sql.VarChar, username);

        // Truy vấn lấy thông tin người dùng từ cơ sở dữ liệu
        const result = await request.query('SELECT username, password, role FROM dbo.users WHERE username = @username');

        if (result.recordset.length > 0) {
            const user = result.recordset[0];

            if (!user.password) {
                console.error('Password not found for user:', username);
                return res.status(500).json({ errors: [{ msg: 'Password not found for user' }] });
            }

            // So sánh mật khẩu nhập vào với mật khẩu đã mã hóa
            const match = await bcrypt.compare(password, user.password);

            if (match) {
                req.session.user = { username: user.username, role: user.role };
                console.log('Login successful, session:', req.session.user);
                res.status(200).send('Login successful in port 3002');
            } else {
                console.log('Invalid password for user:', username);
                res.status(401).send('Wrong password');
            }
        } else {
            console.log('Invalid credentials for user:', username);
            res.status(401).send('User does not exists');
        }
    } catch (err) {
        console.error('Error during login:', err);
        return res.status(500).json({ errors: [{ msg: 'Error during login' }] });
    }
};

// API lấy thông tin người dùng ('/api/user')
exports.getAccount = async (req, res) => {
    const {username} = req.session.user;

    if(!username) {
        return res.status(401).send('User not logged in');
    }

    try {
        const request = new sql.Request();
        const result = await request.query(`Select username from dbo.users where username = '${username}'`);

        if(result.recordset.length > 0) {
            const user = result.recordset[0]; // Lấy thông tin người dùng
            res.status(200).json({username: user.username});
        } else {
            res.status(404).send('User not fond');
        }
    } catch (err) {
        console.error('Error fetching user: ', err);
        res.status(500).send('Error fetching user');
    }
}
