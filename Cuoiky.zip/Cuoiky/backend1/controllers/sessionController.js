const redis = require('redis');
const RedisStore = require('connect-redis').default;
const session = require('express-session');

// Tạo Redis client
const redisClient = redis.createClient({
    url: 'redis://redis:6379' // Địa chỉ Redis
});

// Xử lý lỗi Redis
redisClient.on('error', (err) => {
    console.error('Redis error:', err);
});

// Kết nối Redis
const connectRedis = async () => {
    try {
        await redisClient.connect();
        console.log('Redis client connected successfully');
    } catch (err) {
        console.error('Failed to connect to Redis:', err);
        process.exit(1); // Dừng ứng dụng nếu không thể kết nối Redis
    }
};

// Cấu hình session
const sessionConfig = session({
    store: new RedisStore({ client: redisClient }), // Sử dụng Redis Store
    secret: 'admin123', // Mật khẩu cho session
    resave: false,
    saveUninitialized: true,
    cookie: {
        secure: process.env.NODE_ENV === 'production', // Nếu sản xuất, cookie phải được bảo mật
        httpOnly: true,
        sameSite: 'lax'
    }
});

// Middleware kiểm tra session
const checksession = (req, res, next) => {
    if (req.session.user) {
        next(); // Nếu session tồn tại, tiếp tục
    } else {
        res.status(401).send('Unauthorized'); // Không có session, trả về lỗi 401
    }
};

// API kiểm tra session
const apiCheckSession = (req, res) => {
    if (req.session && req.session.user) {
      res.status(200).json({ loggedIn: true, user: req.session.user });
    } else {
      res.status(200).json({ loggedIn: false });
    }
};

// Middleware kiểm tra quyền Admin
const checkAdmin = (req, res, next) => {
    if (req.session.user && req.session.user.role === 'admin') {
        next(); // Người dùng là admin, tiếp tục
    } else {
        return res.status(403).json({ message: 'Access denied. Only admin' });
    }
};

// Middleware kiểm tra quyền Customer
const checkCustomer = (req, res, next) => {
    if (req.session.user && req.session.user.role === 'customer') {
        next(); // Người dùng là customer, tiếp tục
    } else {
        return res.status(403).json({ message: 'Access denied. Only customer' });
    }
};

// Xuất các hàm để sử dụng
module.exports = {
    connectRedis,
    sessionConfig,
    checksession,
    apiCheckSession,
    checkAdmin,
    checkCustomer
};
