const express = require('express');
const path = require('path');
const cors = require('cors');
const accountRoutes = require('./routes/accountRoute');
const productRoutes = require('./routes/productRoute');
const connectDB = require('./database/connectDB')
const sessionRoutes = require('./routes/sessionRoute');
const sessionController = require('./controllers/sessionController');



// Cập nhật nhập RedisStore
const app = express();
const port = process.env.PORT || 3001;

// Cấu hình CORS
app.use(cors({
    origin: 'http://localhost:3000',
    credentials: true
}));

app.use(express.json());
// Kết nối tới cơ sở dữ liệu
connectDB()
    .then(() => {
        console.log('Connected to the database');
    })
    .catch((err) => {
        console.error('Error connecting to the database:', err);
    });

sessionController.connectRedis(); // Kết nối Redis trước khi khởi động server
app.use(sessionController.sessionConfig); // Đưa vào middleware session từ sessionController.js


// Router
app.use('/api/accounts', accountRoutes);
app.use('/api/products', productRoutes);
app.use('/api/session', sessionRoutes);


// Cấu hình phục vụ tệp tĩnh từ thư mục Nginx HTML
app.use(express.static(path.join('/usr/share/nginx/html')));

// Route bắt tất cả yêu cầu và trả về file index.html
app.get('*', (req, res) => {
    res.sendFile(path.join('/usr/share/nginx/html', 'index.html'), (err) => {
        if (err) {
            console.error('Error sending index.html:', err); // Log lỗi khi gửi index.html
            res.status(err.status).end();
        }
    });
});

// Khởi động server backend
app.listen(port, () => {
    console.log(`Backend server running on port ${port}`);
});
