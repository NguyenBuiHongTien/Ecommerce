const express = require('express');
const { registerValidation, loginValidation } = require('./validators/accountRouteValidator');
const { createAccount, login, getAccount } = require('../controllers/accountController');
const { validationResult } = require('express-validator');

const router = express.Router();

// Helper to check validation results
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    // Return validation errors in the expected format
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};

// Create Account Route
router.post('/register', registerValidation, validateRequest, createAccount);

// Login Route
router.post('/login', loginValidation, validateRequest, login);

// GetAllAccount Route
router.get('/user', getAccount);

module.exports = router;
