const session = require('express-session');
const express = require('express');
const { apiCheckSession } = require('../controllers/sessionController');
const router = express.Router();

router.get('/check-session', apiCheckSession);

module.exports = router;