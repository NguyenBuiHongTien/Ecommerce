const express = require('express');
const {
  createProductValidation,
  updateProductValidation,
  deleteProductValidation,
  getProductByIdValidation,
} = require('./validators/productRouteValidator');
const { createProduct, updateProduct, deleteProduct, getAllProduct, getProductById } = require('../controllers/productController');
const { checkAdmin } = require('../controllers/sessionController');
const { validationResult } = require('express-validator');

const router = express.Router();

// Helper to check validation results
const validateRequest = (req, res, next) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  next();
};

// Create Product Router
router.post('/products', checkAdmin, createProductValidation, validateRequest, createProduct);

// Update Product Router
router.put('/products/:id', checkAdmin, updateProductValidation, validateRequest, updateProduct);

// Delete Product Router
router.delete('/products/:id', checkAdmin, deleteProductValidation, validateRequest, deleteProduct);

// Get All Product
router.get('/products', getAllProduct);

// Get Product by ID
router.get('/products/:id', getProductByIdValidation, validateRequest, getProductById);

module.exports = router;
