// productRouteValidator.js
const { body, param } = require('express-validator');

const createProductValidation = [
  body('name')
    .isString().withMessage('Product name must be a string')
    .notEmpty().withMessage('Product name cannot be empty')
    .trim(),
  body('price')
    .isFloat({ gt: 0 }).withMessage('Price must be a number greater than 0'),
  body('description')
    .optional()
    .isString().withMessage('Description must be a string')
    .trim(),
  body('category')
    .isString().withMessage('Category must be a string')
    .notEmpty().withMessage('Category cannot be empty')
    .trim(),
  body('stock')
    .isInt({ min: 0 }).withMessage('Stock must be a non-negative integer'),
];

const updateProductValidation = [
  param('id')
    .isMongoId().withMessage('Invalid product ID'),
  body('name')
    .optional()
    .isString().withMessage('Product name must be a string')
    .trim(),
  body('price')
    .optional()
    .isFloat({ gt: 0 }).withMessage('Price must be a number greater than 0'),
  body('description')
    .optional()
    .isString().withMessage('Description must be a string')
    .trim(),
  body('category')
    .optional()
    .isString().withMessage('Category must be a string')
    .trim(),
  body('stock')
    .optional()
    .isInt({ min: 0 }).withMessage('Stock must be a non-negative integer'),
];

const deleteProductValidation = [
  param('id')
    .isMongoId().withMessage('Invalid product ID'),
];

const getProductByIdValidation = [
  param('id')
    .isMongoId().withMessage('Invalid product ID'),
];

module.exports = {
  createProductValidation,
  updateProductValidation,
  deleteProductValidation,
  getProductByIdValidation,
};
