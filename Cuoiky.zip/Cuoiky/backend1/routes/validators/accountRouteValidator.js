// accountRouteValidator.js
const { body } = require('express-validator');

const registerValidation = [
  body('username')
    .isString().withMessage('Username must be a string')
    .isLength({ min: 3 }).withMessage('Username must be at least 3 characters long')
    .trim(),
  body('email')
    .isEmail().withMessage('Please enter a valid email address')
    .normalizeEmail(),
  body('password')
    .isLength({ min: 6 }).withMessage('Password must be at least 6 characters long')
    .matches(/\d/).withMessage('Password must contain at least one number'),
];

const loginValidation = [
  body('username')
    .isString().withMessage('Username must be a string')
    .notEmpty().withMessage('Username cannot be empty'),
  body('password')
    .notEmpty().withMessage('Password cannot be empty')
    .isLength({ min: 6 }).withMessage('Password must be at least 6 characters long'),
];

module.exports = {
  registerValidation,
  loginValidation,
};
