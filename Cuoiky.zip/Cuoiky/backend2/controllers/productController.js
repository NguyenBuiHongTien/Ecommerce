const sql = require('mssql');



// API thêm sản phẩm (admin) ('/api/products')
exports.createProduct = async (req, res) => {
    const { productname, price, description, imageURL } = req.body;

    try {
        const request = new sql.Request();
        request.input('ProductName', sql.VarChar, productname);
        request.input('Price', sql.Decimal, price);
        request.input('Description', sql.VarChar, description);
        request.input('ImageURL', sql.VarChar, imageURL);

        await request.query(
            `INSERT INTO dbo.Products (ProductName, Price, Description, ImageURL) 
            VALUES (@ProductName, @Price, @Description, @ImageURL)`
        );

        res.status(201).json({ message: 'Product added successfully' });
    } catch (err) {
        console.error('Error adding product:', err);
        res.status(500).json({ message: 'Error adding product' });
    }
};

// API cập nhật sản phẩm (admin) ('/api/products/:id')
exports.updateProduct = async (req, res) => {
    const { id } = req.params;
    const { productname, price, description } = req.body;

    try {
        const request = new sql.Request();
        request.input('ProductID', sql.Int, id);
        request.input('ProductName', sql.VarChar, productname);
        request.input('Price', sql.Decimal, price);
        request.input('Description', sql.VarChar, description);

        await request.query(
            `UPDATE dbo.Products 
            SET ProductName = @ProductName, Price = @Price, Description = @Description 
            WHERE ProductID = @ProductID`
        );

        res.status(200).json({ message: 'Product updated successfully' });
    } catch (err) {
        console.error('Error updating product:', err);
        res.status(500).json({ message: 'Error updating product' });
    }
};

// API Xóa sản phẩm ('/api/products/:id')
exports.deleteProduct = async (req, res) => {
    const { id } = req.params;

    try {
        const request = new sql.Request();
        request.input('ProductID', sql.Int, id);

        await request.query(`DELETE FROM dbo.Products WHERE ProductID = @ProductID`);
        res.status(200).json({ message: 'Product deleted successfully' });
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ message: 'Error deleting product' });
    }
};


// API Lấy danh sách sản phẩm ('/api/products')
exports.getAllProduct = async (req, res) => {
    try {
        const request = new sql.Request();
        const result = await request.query('SELECT * FROM dbo.Products');
        res.status(200).json(result.recordset);
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({ message: 'Error fetching products' });
    }
};

// API Lấy chi tiết sản phẩm theo id ('/api/products/:id')
exports.getProductById = async (req, res) => {
    const { id } = req.params;

    try {
        const request = new sql.Request();
        request.input('ProductID', sql.Int, id);

        const result = await request.query(
            `SELECT * FROM dbo.Products WHERE ProductID = @ProductID`
        );

        if (result.recordset.length === 0) {
            return res.status(404).json({ message: 'Product not found' });
        }

        res.status(200).json(result.recordset[0]);
    } catch (error) {
        console.error('Error fetching product by ID:', error);
        res.status(500).json({ message: 'Error fetching product' });
    }
};


